import os
from flask import *
from werkzeug.utils import secure_filename

from src.dbconnectionnew import *
app=Flask(__name__)

@app.route('/login',methods=['post'])
def login():
     username=request.form['username']
     password=request.form['password']
     qry="SELECT * FROM `login` WHERE `username`=%s AND `password`=%s "
     val=(username,password)
     res=selectone(qry,val)
     if res is None:
         return jsonify({'task':"invalid"})
     else:
         return jsonify({'task':"valid","id":res['login_id'],"type":res['type']})


@app.route('/reg',methods=['post'])
def reg():
 try:
    fnm = request.form['fname']
    lnm = request.form['lname']
    place = request.form['place']
    post = request.form['post']
    pin = request.form['pin']
    contact = request.form['phone']
    email = request.form['email']
    un = request.form['uname']
    pwd = request.form['psw']
    qry="INSERT INTO `login` VALUES (NULL,%s,%s,'user')"
    val = (un,pwd)
    lid = iud(qry, val)
    qry="INSERT INTO `user` VALUES(NULL,%s,%s,%s,%s,%s,%s,%s,%s)"
    val = (lid,fnm,lnm,place,post,pin,contact,email)
    res = iud(qry, val)
    return jsonify({'task': "success"})
 except Exception as e:
    return jsonify({'task': "already exist"})

# except Exception as e:
# print(e)
# return jsonify({'task': 'error'})

@app.route('/view_user', methods=['post'])
def view_user ():
    lid = request.form['lid']
    qry = "SELECT * FROM `user`  WHERE `login_id`  NOT IN (SELECT `from_id` FROM `request` WHERE `to_id`=%s union SELECT `to_id` FROM `request` WHERE `from_id` =%s) AND `user`.`login_id` !=%s"
    res=selectall2(qry,(lid,lid,lid))
    print(res)
    return jsonify(res)

@app.route('/send_friend_req', methods=['post'])
def send_friend_req():
    print(request.form)
    from_id=request.form['from_id']
    to_id=request.form['to_id']
    iud("INSERT `request` (`from_id`,`to_id`,`date`,`status`) VALUES(%s,%s,CURDATE(),'pending')",(from_id,to_id))
    return jsonify(task="success")


@app.route('/view_friend_req', methods=['post'])
def view_friend_req():
    lid=request.form['lid']
    qry="SELECT * FROM `request` JOIN `user` ON `request`.`from_id`=`user`.`login_id` AND `request`.`to_id`=%s and `request`.`status`='pending'"
    res=selectall2(qry,lid)
    print(res)
    return jsonify(res)

@app.route('/accept_friend_req', methods=['post'])
def accept_friend_req():
    rid=request.form['req']
    iud("UPDATE `request` SET `status`='accepted' WHERE `reg_id`=%s",rid)
    return jsonify({'task': "success"})

@app.route('/reject_friend_req', methods=['post'])
def reject_friend_req():
    rid=request.form['req']
    iud("UPDATE `request` SET `status`='rejected' WHERE `reg_id`=%s",rid )
    return jsonify({'task': "success"})

@app.route('/sendcomplaint',methods=['post'])
def sendcomplaint():
    uid = request.form["lid"]
    complaint = request.form["com"]
    qry = "insert into complaint values(null,%s,%s,'pending',curdate())"
    val = (uid, complaint)
    iud(qry, val)
    return jsonify({'task': 'valid'})

@app.route('/viewreply', methods=['post'])
def viewreply():
    uid = request.form["lid"]
    qry="select * from complaint where login_id=%s"
    res=selectall2(qry,uid)
    return jsonify(res)

@app.route('/view_current_status', methods=['POST'])
def view_current_status():
    lid = request.form['lid']
    q="SELECT * FROM `bus` WHERE `lid`=%s"
    res=selectone(q,lid)
    return jsonify(res)

@app.route('/update_bus_status', methods=['POST'])
def update_bus_status():
    lid=request.form['lid']
    status=request.form['status']
    q="UPDATE `bus` SET `status`=%s WHERE `lid`=%s"
    val=(status,lid)
    res=iud(q,val)
    return jsonify({"task":"success"})


@app.route('/viewroute', methods=['post'])
def viewroute():

    qry="SELECT * FROM`route` "
    res=selectall(qry)
    print(res)
    return jsonify(res)

@app.route('/viewstop', methods=['post'])
def viewstop():
    rid=request.form['rid']
    qry="SELECT * FROM `stop` WHERE route_id=%s order by stop_no"
    res=selectall2(qry,rid)
    return jsonify(res)

@app.route('/view_bus', methods=['post'])
def view_bus ():
    print(request.form)
    rid = request.form['routeid']
    fsid = request.form['fsid']
    tsid = request.form['tsid']
    print(rid)
    qry="SELECT * FROM `bus` JOIN `location` ON `location`.`login_id`=`bus`.`lid` WHERE bus.`lid` IN(SELECT `bus_id` FROM `trip` WHERE `route_id`=%s)"
    res=selectall2(qry,rid)
    print(res)
    result=[]
    for i in res:
        bid=i['lid']
        qry="SELECT `trip_time` FROM `schedule` WHERE `stop_id`=%s AND `trip_id` IN(SELECT `trip_id` FROM `trip` WHERE `bus_id`=%s AND `route_id`=%s)"
        val=(fsid,bid,rid)
        resss=selectall2(qry,val)
        print(resss)
        val=(tsid,bid,rid)
        rests=selectall2(qry,val)
        print(rests)
        for j in range(0,len(resss)):
            row=i
            row['ss']=resss[j]['trip_time']
            row['ts']=rests[j]['trip_time']
            result.append(row)
    print(result)
    return jsonify(result)

#====================================================CHAT===============================================================

@app.route('/view_friends',methods=['post'])
def view_friends():
    lid=request.form['lid']
    qry="SELECT `request`.*,`user`.* FROM `request` JOIN `user` ON `request`.`from_id`=`user`.`login_id` WHERE `request`.`to_id`=%s AND `request`.`status`='accepted' UNION SELECT `request`.*,`user`.* FROM `request` JOIN `user` ON `request`.`to_id`=`user`.`login_id` WHERE `request`.`from_id`=%s AND `request`.`status`='accepted' "
    # qry="SELECT `request`.*,`user`.* FROM `request` JOIN `user` ON `request`.`from_id`=`user`.`login_id` WHERE `user`.`login_id`!=%s AND `request`.`status`='accepted'"
    res=selectall2(qry,(lid,lid))
    print(res)
    return jsonify(res)

@app.route('/view_stop',methods=['post'])
def view_stop():
    lati=request.form['lati']
    logi=request.form['logi']
    qry="SELECT `stop`.*, (3959 * ACOS ( COS ( RADIANS(%s) ) * COS( RADIANS( `stop`.latitude) ) * COS( RADIANS( `stop`.longitude ) - RADIANS(%s) ) + SIN ( RADIANS(%s) ) * SIN( RADIANS( `stop`.latitude ) ))) AS user_distance FROM `stop` HAVING user_distance < 31.068 order by user_distance"
    # qry="SELECT `request`.*,`user`.* FROM `request` JOIN `user` ON `request`.`from_id`=`user`.`login_id` WHERE `user`.`login_id`!=%s AND `request`.`status`='accepted'"
    res=selectall2(qry,(lati,logi,lati))
    print(res)
    return jsonify(res)

@app.route('/in_message2',methods=['post'])
def in_message():
    # print(request.form)
    fromid = request.form['fid']
    # print("fromid",fromid)

    toid = request.form['toid']
    # print("toid",toid)

    message=request.form['msg']
    print("msg",message) 
    qry = "INSERT INTO `chat` (`from_id`,`to_id`,`message`,`date`,type) VALUES(%s,%s,%s,CURDATE(),'msg')"
    value = (fromid, toid, message)
    # print("pppppppppppppppppp")
    # print(value)
    iud(qry, value)
    return jsonify(status='send')

@app.route('/in_message3',methods=['post'])
def in_message3():
    # print(request.form)
    fromid = request.form['fid']
    # print("fromid",fromid)

    toid = request.form['toid']
    # print("toid",toid)

    message=request.form['msg']
    print("msg",message)
    qry = "INSERT INTO `chat` (`from_id`,`to_id`,`message`,`date`,type) VALUES(%s,%s,%s,CURDATE(),'loc')"
    value = (fromid, toid, message)
    # print("pppppppppppppppppp")
    # print(value)
    iud(qry, value)
    return jsonify(status='send')

@app.route('/view_message2',methods=['post'])
def view_message2():
    # print("wwwwwwwwwwwwwwww")
    # print(request.form)
    fromid=request.form['fid']
    # print(fromid)
    toid=request.form['toid']
    # print(toid)
    lmid = request.form['lastmsgid']
    print("msgggggggggggggggggggggg"+lmid)
    sen_res = []
    # qry="SELECT * FROM chat WHERE (fromid=%s AND toid=%s) OR (fromid=%s AND toid=%s) ORDER BY DATE ASC"
    qry="SELECT `from_id`,`message`,`date`,`chat_id`,type FROM `chat` WHERE `chat_id`>%s AND ((`to_id`=%s AND  `from_id`=%s) OR (`to_id`=%s AND `from_id`=%s)  )  ORDER BY chat_id ASC"
    print("SELECT `from_id`,`message`,`date`,`chat_id`,type FROM `chat` WHERE `chat_id`>%s AND ((`to_id`=%s AND  `from_id`=%s) OR (`to_id`=%s AND `from_id`=%s)  )  ORDER BY chat_id ASC")
    val=(str(lmid),str(toid),str(fromid),str(fromid),str(toid))
    print("fffffffffffff",val)
    res = selectall2(qry,val)
    print("resullllllllllll")
    print(res)
    if res is not None:
        return jsonify(status='ok', res1=res)
    else:
        return jsonify(status='not found')



#==========================LOCATION+====================================================

@app.route('/addlocation', methods=['POST'])
def addlocation():

    lid=request.form['uid']
    lati=request.form['lati']
    longi=request.form['longi']
    q="SELECT * FROM `location` WHERE `login_id`=%s"
    res=selectone(q,lid)

    # if len(res) <=0:
    if res is None:
        qry="INSERT INTO `location` (`login_id`,`latitude`,`longitude`) VALUES (%s,%s,%s)"
        val=(lid,longi,lati)
        iud(qry,val)
        return jsonify({"task":"inserted"})
    else:
        qry="UPDATE `location` SET `latitude`=%s,`longitude`=%s WHERE `login_id`=%s"
        val=(lati,longi,lid)
        iud(qry,val)
        return jsonify({"task": "updated"})



app.run(host="0.0.0.0",port="5000")